<template>
  <section class="page" tabindex="0">
    <!-- Top filters -->
    <header class="header">
      <div class="h-title">
        <div class="t1">Recipe Test</div>
        <div class="t2">CAS → JOB → RECIPE</div>
      </div>

      <div class="filters">
        <div class="f">
          <div class="l">Line</div>
          <select class="ctl" v-model="line">
            <option v-for="v in filteredLineOptions" :key="v" :value="v">{{ v }}</option>
          </select>
        </div>

        <div class="f">
          <div class="l">분임조</div>
          <select class="ctl" v-model="team">
            <option v-for="v in filteredTeamOptions" :key="v" :value="v">{{ v }}</option>
          </select>
        </div>

        <div class="f">
          <div class="l">설비ID</div>
          <select class="ctl" v-model="eqpId">
            <option v-for="v in filteredEqpOptions" :key="v" :value="v">{{ v }}</option>
          </select>
        </div>

        <button class="btn" @click="load(false)">Load</button>
      </div>
    </header>

    <div class="grid">
      <!-- CAS LIST -->
      <section
        class="w97-panel cas-panel"
        :class="{ 'pane-focus': activePane==='casList' }"
        :style="casPanelStyle"
        @mousedown="activateArea('casList', 'cas')"
        @contextmenu.prevent="openListMenu('cas', $event)"
      >
        <div class="w97-titlebar">
          <span class="w97-title">CAS</span>
          <input
            class="win-input w97-find"
            :class="casClass"
            v-model="casQueryModel"
            placeholder="예: CAS40"
            @keydown.enter="applyCasSearch(true)"
            @focus="activateArea('casList', 'cas')"
          />
          <button class="win-btn iconbtn" @click="applyCasSearch(true)" aria-label="search">🔍</button>
        </div>

        <div class="list-head" ref="casHeadEl"><div class="list-head-track" :style="{ transform: `translateX(${-casScrollLeft}px)` }">
          <div class="head-cell name-col" :style="{ width: casListColWidths.name + 'px' }" @click="toggleSort(casSortKey as any, casSortDir, 'name')">
            File Name
            <span class="col-resizer" @mousedown.prevent.stop="startListResize('cas', 'name', $event)"></span>
          </div>
          <div class="head-cell time-col" :style="{ width: casListColWidths.modifiedAt + 'px' }" @click="toggleSort(casSortKey as any, casSortDir, 'modifiedAt')">
            Modified Time
            <span class="col-resizer" @mousedown.prevent.stop="startListResize('cas', 'modifiedAt', $event)"></span>
          </div>
        </div></div>

        <div v-if="casHint" class="w97-hint">{{ casHint }}</div>

        <div class="w97-scroll" ref="casScrollEl" @scroll="onListBodyScroll('cas')">
          <div class="w97-col list-col-wide" v-for="(col, idx) in casCols" :key="idx">
            <ul class="w97-ul">
              <li
                v-for="c in col"
                :key="c.name"
                class="w97-li w97-li-row"
                :class="{ active: selectedCas.has(c.name) }"
                @click="onCasClick(c.name, $event)"
                :ref="(el) => setCasRef(c.name, el as HTMLElement | null)"
              >
                <span class="cell-name name-col" :style="{ width: casListColWidths.name + 'px' }" :title="c.name">
                  {{ c.name }}
                </span>
                <span class="cell-time time-col" :style="{ width: casListColWidths.modifiedAt + 'px' }">
                  {{ c.modifiedAt }}
                </span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      <!-- CAS CONTENT -->
      <section
        class="cas-content"
        :class="{ open: casContentVisible, 'pane-focus': activePane==='casContent' }"
        :style="casContentStyle"
        @mousedown="activateArea('casContent', 'cas')"
        @contextmenu.prevent="openContentMenu('casContent', $event)"
      >
        <Transition name="slideCard">
          <div v-if="casContentVisible" class="cas-win97">
            <div class="cas-bar">
              <div class="cas-bar-left">Cas Content</div>
              <div class="cas-bar-right">
                <span class="cas-id">{{ casSelectedSingle }}</span>
                <span v-if="casEditMode" class="edit-pill">EDIT</span>
                <button v-if="!casEditMode" class="win-btn save-btn" @click="casContentEnterEdit()">Edit</button>
                <button v-if="casEditMode" class="win-btn save-btn" @click="casSaveClicked()">Save</button>
              </div>
            </div>

            <div class="cas-tabs">
              <button class="win-tab" :class="{ active: casTab==='standard' }" @click="casTab='standard'">Standard</button>
              <button class="win-tab" :class="{ active: casTab==='pre' }" @click="casTab='pre'">Pre-Polish</button>
              <button class="win-tab" :class="{ active: casTab==='gating' }" @click="casTab='gating'">Gating & Rework</button>
              <button class="win-tab" :class="{ active: casTab==='post' }" @click="casTab='post'">Post Rework</button>
            </div>

            <div class="cas-body">
              <div v-if="casTab==='standard'">
                <div class="cas-std-hint">Slot # (1~24) / Job Name</div>

                <div class="cas-table-wrap">
                  <table class="cas-table">
                    <colgroup>
                      <col v-for="(w, i) in tableColWidths.cas" :key="`cas-col-${i}`" :style="{ width: `${w}px` }" />
                    </colgroup>
                    <thead>
                      <tr>
                        <th
                          v-for="(label, i) in casTableHeaders"
                          :key="label"
                          :class="{ clickable: i === 1 }"
                          @click="onCasTableHeaderClick(i)"
                        >
                          <span class="th-label">{{ label }}</span>
                          <span
                            v-if="i < casTableHeaders.length - 1"
                            class="col-resizer"
                            @mousedown.prevent.stop="startResize('cas', i, $event)"
                          ></span>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="row in casTableRows" :key="row.slot">
                        <td class="center cas-td">{{ row.slot }}</td>
                        <td
                          class="center cas-td cas-cell"
                          :class="{ sel: casEditMode && selectedSlotCells.has(row.slot), clickable: !casEditMode }"
                          @click="onCasCellClick(row.slot, row.jobName, $event)"
                        >
                          {{ row.jobName }}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <div v-if="casEditMode" class="cas-edit-hint">
                  Job Name 셀 선택 후 Job List에서 Job 클릭 → 선택된 Slot들의 Job Name이 변경됩니다. (Ctrl/Shift)
                </div>
              </div>

              <div v-else class="cas-todo">(준비중) {{ casTabLabel }}</div>
            </div>
          </div>
        </Transition>
      </section>

      <!-- JOB LIST -->
      <section
        class="w97-panel job-panel"
        :class="{
          'pane-focus': activePane==='jobList',
          'attention-job-list': jobListAttention
        }"
        :style="jobPanelStyle"
        @mousedown="activateArea('jobList', 'job')"
        @contextmenu.prevent="openListMenu('job', $event)"
      >
        <div class="w97-titlebar">
          <span class="w97-title">JOB</span>
          <input
            class="win-input w97-find"
            :class="jobClass"
            v-model="jobQueryModel"
            placeholder="예: JOB47"
            @keydown.enter="applyJobSearch(true)"
            @focus="activateArea('jobList', 'job')"
          />
          <button class="win-btn iconbtn" @click="applyJobSearch(true)" aria-label="search">🔍</button>
        </div>

        <div class="list-head" ref="jobHeadEl"><div class="list-head-track" :style="{ transform: `translateX(${-jobScrollLeft}px)` }">
          <div class="head-cell name-col" :style="{ width: jobListColWidths.name + 'px' }" @click="toggleSort(jobSortKey as any, jobSortDir, 'jobName')">
            File Name
            <span class="col-resizer" @mousedown.prevent.stop="startListResize('job', 'name', $event)"></span>
          </div>
          <div class="head-cell time-col" :style="{ width: jobListColWidths.modifiedAt + 'px' }" @click="toggleSort(jobSortKey as any, jobSortDir, 'modifiedAt')">
            Modified Time
            <span class="col-resizer" @mousedown.prevent.stop="startListResize('job', 'modifiedAt', $event)"></span>
          </div>
        </div></div>

        <div v-if="jobHint" class="w97-hint">{{ jobHint }}</div>

        <div class="w97-scroll job-scroll" ref="jobScrollEl" @scroll="onListBodyScroll('job')">
          <div class="w97-col list-col-wide" v-for="(col, idx) in jobCols" :key="idx">
            <ul class="w97-ul">
              <li
                v-for="j in col"
                :key="j.id"
                class="w97-li w97-li-row"
                :class="{ active: selectedJobs.has(j.id) }"
                @click="onJobClick(j.id, $event)"
                :ref="(el) => setJobRef(j.id, el as HTMLElement | null)"
              >
                <span class="cell-name name-col" :style="{ width: jobListColWidths.name + 'px' }" :title="j.jobName">
                  {{ j.jobName }}
                </span>
                <span class="cell-time time-col" :style="{ width: jobListColWidths.modifiedAt + 'px' }">
                  {{ j.modifiedAt ?? '' }}
                </span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      <!-- JOB CONTENT -->
      <section
        class="content"
        :class="{ 'pane-focus': activePane==='jobContent' }"
        :style="contentPaneStyle"
        @mousedown="activateArea('jobContent', 'job')"
        @contextmenu.prevent="openContentMenu('jobContent', $event)"
      >
        <Transition name="slideCard">
          <div v-if="showJobContent" class="card content-card" :style="{ height: paneHeight }" ref="jobContentEl">
            <div class="ch">
              <div class="job-head-left">
                <div class="ct">{{ selectedJobSingleReal?.jobName }}</div>
                <div class="sub">
                  <button
                    v-if="selectedJobSingleReal?.recipe?.name"
                    type="button"
                    class="recipe-link-btn"
                    @click="openJobBaseRecipe()"
                  >
                    {{ selectedJobSingleReal?.recipe.name }}
                  </button>
                </div>
              </div>

              <div class="job-head-right">
                <span v-if="jobEditMode" class="edit-pill edit-pill-strong">EDIT</span>

                <template v-if="!jobEditMode">
                  <button class="win-btn save-btn" @click="jobContentEnterEdit()">Edit</button>
                </template>
                <template v-else>
                  <button class="win-btn save-btn" @click="jobSaveClicked()">Save</button>
                  <button class="win-btn" @click="jobCancelRequested()">Cancel</button>
                </template>
              </div>
            </div>

            <div class="job-classic">
              <div class="bar">
                <div class="bar-left">Perform Dry Metrology Pre Measurement</div>
                <div class="bar-right">
                  <span class="bar-label">Pi Metrology Recipe</span>
                  <select class="bar-select" v-model="piPre">
                    <option value="NONE">None</option>
                    <option value="DATA">DATA</option>
                  </select>
                </div>
              </div>

              <div class="group">
                <div class="group-head">HCLU Clean Recipe Polished Measurement</div>

                <div class="tbl-wrap tight-tbl">
                  <table class="tbl polished">
                    <colgroup>
                      <col v-for="(w, i) in tableColWidths.polished" :key="`polished-col-${i}`" :style="{ width: `${w}px` }" />
                    </colgroup>
                    <thead>
                      <tr>
                        <th v-for="(label, i) in polishedHeaders" :key="label">
                          <span class="th-label">{{ label }}</span>
                          <span
                            v-if="i < polishedHeaders.length - 1"
                            class="col-resizer"
                            @mousedown.prevent.stop="startResize('polished', i, $event)"
                          ></span>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td class="rowname">This Recipe</td>
                        <td class="cell platen1 click" @click="onJobRecipeCellClick(1)">{{ jobPlatenRecipeName(1) }}</td>
                        <td class="cell platen2 click" @click="onJobRecipeCellClick(2)">{{ jobPlatenRecipeName(2) }}</td>
                        <td class="cell platen3 click" @click="onJobRecipeCellClick(3)">{{ jobPlatenRecipeName(3) }}</td>
                      </tr>

                      <tr v-for="n in 8" :key="n">
                        <td class="rowname">Recipe</td>
                        <td class="cell platen1 white">{{ recipeModuleCell }}</td>
                        <td class="cell platen2 sky">{{ recipeModuleCell }}</td>
                        <td class="cell platen3 white">{{ recipeModuleCell }}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <div class="group">
                <div class="group-head">HCLU Clean Recipe Unload</div>
                <div class="tbl-wrap tight-tbl">
                  <table class="tbl small">
                    <colgroup>
                      <col v-for="(w, i) in tableColWidths.unload" :key="`unload-col-${i}`" :style="{ width: `${w}px` }" />
                    </colgroup>
                    <thead>
                      <tr>
                        <th v-for="(label, i) in unloadHeaders" :key="label">
                          <span class="th-label">{{ label }}</span>
                          <span
                            v-if="i < unloadHeaders.length - 1"
                            class="col-resizer"
                            @mousedown.prevent.stop="startResize('unload', i, $event)"
                          ></span>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="n in 5" :key="n">
                        <td class="cell center white">{{ n }}</td>
                        <td class="cell white">{{ unloadModule === 'DATA' ? 'DATA' : '(None)' }}</td>
                        <td class="cell white">{{ unloadModule === 'DATA' ? 'DATA' : '(None)' }}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <div class="bar">
                <div class="bar-left">Perform Dry Metrology Post Measurement</div>
                <div class="bar-right">
                  <span class="bar-label">Pi Metrology Recipe</span>
                  <select class="bar-select" v-model="piPost">
                    <option value="NONE">None</option>
                    <option value="DATA">DATA</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        </Transition>

        <div v-if="!showJobContent" class="content-placeholder" :style="{ height: paneHeight }"></div>
      </section>
    </div>

    <!-- RECIPE CONTENT -->
    <Transition name="slideDown">
      <section
        v-if="recipePanelOpen"
        class="bottom-recipe"
        ref="legacyPanelEl"
        @mousedown="activateArea('recipeArea', 'recipe')"
        @click.capture="onRecipeAreaClick"
        @contextmenu.prevent="openListMenu('recipe', $event)"
      >
        <div class="legacy-window">
          <div class="legacy-top">
            <div class="legacy-titlebar">
              <span class="legacy-title">RECIPE</span>

              <input
                class="win-input find-input"
                :class="recipeFindClass"
                v-model="recipeFindModel"
                placeholder="예: RECIPE13"
                @keydown.enter="applyRecipeFind(true)"
                @focus="activateArea('recipeArea', 'recipe')"
              />
              <button class="win-btn iconbtn" @click="applyRecipeFind(true)" aria-label="search">🔍</button>

              <span class="legacy-meta">Platen {{ activePlaten }}</span>
              <div class="spacer"></div>
            </div>

            <div class="okhide">
              <button class="win-btn" @click="closeRecipePanel()">OK</button>
              <button class="win-btn" @click="closeRecipePanel()">Hide</button>
            </div>
          </div>

          <div class="recipe-scroll" ref="recipeScrollEl">
            <div class="recipe-col" v-for="(col, idx) in recipeCols" :key="idx">
              <ul class="list-ul">
                <li
                  v-for="r in col"
                  :key="r.id"
                  class="list-li"
                  :class="{ active: selectedRecipes.has(r.id) }"
                  @click="onRecipePick(r.id, $event)"
                  :ref="(el) => setRecipeRef(r.id, el as HTMLElement | null)"
                >
                  {{ r.name }}
                </li>
              </ul>
            </div>
          </div>

          <div class="grid-wrap" v-if="selectedRecipeSingle">
            <table class="legacy-table">
              <thead>
                <tr>
                  <th v-for="c in selectedRecipeSingle.columns" :key="c">{{ c }}</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(row, i) in selectedRecipeSingle.rows" :key="i">
                  <td v-for="c in selectedRecipeSingle.columns" :key="c">{{ row[c] ?? '' }}</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div v-else class="legacy-empty">
            <div v-if="selectedRecipes.size > 1">다중 선택 상태라 컨텐츠를 표시하지 않습니다.</div>
            <div v-else>Recipe를 선택하세요.</div>
          </div>

          <div class="recipe-bottom-pad"></div>
        </div>

        <div class="page-bottom-pad"></div>
      </section>
    </Transition>

    <!-- Context menu -->
    <div v-if="ctxMenu.open" class="w97-menu" :style="{ left: ctxMenu.x + 'px', top: ctxMenu.y + 'px' }">
      <div
        v-for="(it, idx) in ctxMenu.items"
        :key="idx"
        class="w97-menu-item"
        @click.stop="it.action()"
      >
        {{ it.label }}
      </div>
    </div>

    <!-- Confirm modal -->
    <div v-if="confirmModal.open" class="w97-modal-overlay">
      <div class="w97-modal">
        <div class="w97-modal-titlebar">
          <div class="w97-modal-title">Confirm</div>
        </div>
        <div class="w97-modal-body">{{ confirmModal.message }}</div>
        <div class="w97-modal-actions">
          <button class="win-btn" @click="confirmYes()">Yes</button>
          <button class="win-btn" @click="confirmNo()">No</button>
        </div>
      </div>
    </div>

    <!-- Recipe Picker modal -->
    <div v-if="recipePicker.open" class="w97-modal-overlay">
      <div class="w97-modal picker">
        <div class="w97-modal-titlebar">
          <div class="w97-modal-title">RECIPE</div>
        </div>

        <div class="w97-modal-body">
          <div class="legacy-titlebar picker-titlebar">
            <span class="legacy-title">RECIPE</span>
            <input
              class="win-input find-input"
              :class="recipePickerFindClass"
              v-model="recipePickerQueryModel"
              placeholder="Find..."
              @keydown.enter="applyRecipePickerFind(true)"
            />
            <button class="win-btn iconbtn" @click="applyRecipePickerFind(true)" aria-label="search">🔍</button>
            <span class="legacy-meta">Platen {{ recipePicker.platen }}</span>
            <div class="spacer"></div>
          </div>

          <div v-if="recipePickerHint" class="w97-hint picker-hint">{{ recipePickerHint }}</div>

          <div class="picker-grid">
            <div class="recipe-scroll picker-scroll">
              <div class="recipe-col" v-for="(col, idx) in recipePickerCols" :key="idx">
                <ul class="list-ul">
                  <li
                    v-for="r in col"
                    :key="r.id"
                    class="list-li"
                    :class="{ active: r.id === recipePicker.previewId }"
                    @click="onRecipePickerItemClick(r.id)"
                    @dblclick="pickRecipeForJob(previewRecipe!)"
                    :ref="(el) => setRecipePickerRef(r.id, el as HTMLElement | null)"
                  >
                    {{ r.name }}
                  </li>
                </ul>
              </div>
            </div>

            <div class="picker-preview">
              <div class="picker-preview-title">Preview: {{ previewRecipe?.name ?? '' }}</div>

              <div v-if="previewRecipe" class="picker-preview-tablewrap">
                <table class="legacy-table">
                  <thead>
                    <tr>
                      <th v-for="c in previewRecipe.columns" :key="c">{{ c }}</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(row, i) in previewRecipe.rows.slice(0, 10)" :key="i">
                      <td v-for="c in previewRecipe.columns" :key="c">{{ row[c] ?? '' }}</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div v-else class="legacy-empty">Select a recipe.</div>
            </div>
          </div>
        </div>

        <div class="w97-modal-actions">
          <button class="win-btn" @click="pickRecipeForJob(previewRecipe!)" :disabled="!previewRecipe">Select</button>
          <button class="win-btn" @click="closeRecipePicker()">Close</button>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
// truncated intentionally? no
</script>

<style scoped>
.page { display:grid; gap:14px; padding-bottom:12px; overflow-x:hidden; outline:none; }
.header { display:flex; gap:16px; align-items:flex-end; justify-content:space-between; padding:14px; background:#fff; border:1px solid #e6e8ef; border-radius:14px; box-shadow:0 10px 26px rgba(10,20,40,.06); }
.h-title .t1{ font-size:18px; font-weight:900; color:#111827; }
.h-title .t2{ font-size:12px; color:#6b7280; margin-top:2px; }
.filters{ display:grid; grid-template-columns:1fr 1fr 1.2fr auto; gap:10px; align-items:end; min-width:0; max-width:100%; }
.f{ display:grid; gap:6px; }
.l{ font-size:12px; color:#6b7280; font-weight:800; }
.ctl{ height:36px; padding:0 10px; border:1px solid #cfd6e4; border-radius:12px; outline:none; background:#fff; }
.ctl:focus{ border-color:#6b8cff; box-shadow:0 0 0 3px rgba(107,140,255,.18); }
.btn{ height:36px; padding:0 14px; border-radius:12px; border:1px solid #111827; background:#111827; color:#fff; font-weight:900; cursor:pointer; }
.btn:hover{ opacity:.92; }

.grid{ display:flex; gap:14px; align-items:stretch; min-width:0; overflow-x:hidden; }

.cas-panel,
.job-panel,
.cas-content,
.content{
  transition:
    width .34s cubic-bezier(.22,.61,.36,1),
    flex-basis .34s cubic-bezier(.22,.61,.36,1),
    flex-grow .34s cubic-bezier(.22,.61,.36,1),
    box-shadow .24s ease,
    transform .24s ease,
    border-color .24s ease;
}

.cas-panel{ min-width:0; }
.job-panel{ min-width:0; }
.cas-content{ min-width:0; overflow:hidden; }
.cas-content:not(.open){ width:0px; }
.content{ flex:1 1 0%; min-width:0; }

.pane-focus{
  box-shadow:0 0 0 3px rgba(53,119,255,.16);
}

.w97-panel{ background:#c0c0c0; border-top:2px solid #fff; border-left:2px solid #fff; border-right:2px solid #808080; border-bottom:2px solid #808080; padding:6px; display:flex; flex-direction:column; min-width:0; }
.w97-titlebar{ display:flex; align-items:center; gap:8px; background:#d4d0c8; border:1px solid #8d8d8d; padding:6px 8px; font-weight:900; }
.w97-title{ min-width:42px; }
.win-input{ height:22px; padding:2px 6px; background:#fff; border-top:2px solid #808080; border-left:2px solid #808080; border-right:2px solid #fff; border-bottom:2px solid #fff; }
.w97-find{ width:180px; }
.win-btn{ height:24px; background:#c0c0c0; border-top:2px solid #fff; border-left:2px solid #fff; border-right:2px solid #404040; border-bottom:2px solid #404040; cursor:pointer; }
.win-btn:active{ border-top:2px solid #404040; border-left:2px solid #404040; border-right:2px solid #fff; border-bottom:2px solid #fff; }
.iconbtn{ width:34px; min-width:34px; display:flex; align-items:center; justify-content:center; padding:0; }
.find-ok{ background:#d7ffd7; }
.find-bad{ background:#ffd6d6; }
.w97-hint{ padding:6px 8px; color:#7a0000; font-weight:900; font-size:12px; }
.picker-hint{ margin-bottom:8px; }

.list-head{
  display:flex;
  gap:8px;
  margin-top:8px;
  background:#d4d0c8;
  border:1px solid #8d8d8d;
  padding:4px 8px;
  font-weight:900;
}
.head-cell{
  position:relative;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  padding-right:10px;
  cursor:pointer;
  display:flex;
  align-items:center;
}
.head-cell.time-col{
  color:#111;
  border-left:1px solid #8d8d8d;
  padding-left:8px;
}
.list-head-track{
  display:flex;
  gap:8px;
  width:max-content;
  will-change:transform;
}

.w97-scroll{ margin-top:8px; background:#fff; border-top:2px solid #808080; border-left:2px solid #808080; border-right:2px solid #fff; border-bottom:2px solid #fff; display:flex; gap:12px; overflow:auto; padding:8px; flex:1; min-height:0; }
.job-scroll{ padding-left:12px; }
.w97-col{ flex:0 0 160px; min-width:160px; border-right:1px solid #d0d0d0; padding-right:10px; }
.list-col-wide{ flex:0 0 auto; min-width:max-content; }
.w97-ul{ list-style:none; margin:0; padding:0; }
.w97-li{ padding:2px 4px; cursor:pointer; line-height:18px; font-weight:800; }
.w97-li.active{ background:#0a246a; color:#fff; }
.w97-li-row{
  display:flex;
  align-items:center;
  gap:8px;
  overflow:hidden;
}
.cell-name,
.cell-time{
  display:inline-block;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
}
.cell-name.name-col{
  padding-right:8px;
}
.cell-time.time-col{
  border-left:1px solid #c6c6c6;
  padding-left:8px;
  font-size:11px;
  font-weight:400;
  color:#555;
}

.cas-win97{ background:#d4d0c8; border:1px solid #8d8d8d; padding:8px; display:flex; flex-direction:column; gap:8px; position:relative; height:100%; }
.cas-bar{ background:#d4d0c8; border:1px solid #8d8d8d; padding:6px 8px; display:flex; justify-content:space-between; font-weight:900; }
.cas-bar-right{ display:flex; align-items:center; gap:6px; }
.cas-id{ font-weight:900; }
.edit-pill{
  background:#0a246a;
  color:#fff;
  padding:1px 6px;
  border-radius:999px;
  font-size:10px;
  font-weight:900;
}
.edit-pill-strong{
  font-size:11px;
  padding:2px 8px;
}
.save-btn{ height:22px; padding:0 10px; }

.cas-tabs{ display:flex; gap:4px; }
.win-tab{
  background:#c0c0c0;
  border-top:2px solid #fff; border-left:2px solid #fff;
  border-right:2px solid #404040; border-bottom:2px solid #404040;
  padding:2px 6px;
  font-weight:900;
  cursor:pointer;
  font-size:11px;
  line-height:1;
}
.win-tab:active{
  border-top:2px solid #404040; border-left:2px solid #404040;
  border-right:2px solid #fff; border-bottom:2px solid #fff;
}
.win-tab.active{ background:#0a246a; color:#fff; }

.cas-body{ flex:1; overflow:auto; background:#e6e2da; border:1px solid #8d8d8d; padding:8px; }
.cas-std-hint{ font-weight:900; font-size:12px; color:#333; margin-bottom:6px; }
.cas-table-wrap{ background:#fff; border-top:2px solid #808080; border-left:2px solid #808080; border-right:2px solid #fff; border-bottom:2px solid #fff; overflow:auto; }
.cas-table{ width:max-content; min-width:100%; border-collapse:collapse; font-size:12px; table-layout:fixed; }
.cas-table th{ background:#d4d0c8; font-weight:900; padding:4px 6px; border:1px solid #808080; position:relative; }
.cas-table th.clickable{ cursor:pointer; }
.cas-table th.clickable:hover{ background:#cfc9be; }
.cas-td{ border:1px solid #808080; padding:2px 4px; font-size:10px; white-space:nowrap; }
.cas-cell.sel{ background:#0a246a; color:#fff; }
.cas-cell.clickable{
  cursor:pointer;
  color:#0b3aa4;
  font-weight:900;
}
.cas-cell.clickable:hover{
  text-decoration:underline;
  background:#eaf7ff;
}
.cas-td.ro{ background:#fff; }
.cas-edit-hint{ margin-top:8px; font-size:11px; font-weight:900; color:#333; }
.center{ text-align:center; }
.cas-todo{ padding:10px; background:#fff; border:1px dashed #999; font-weight:900; color:#6b7280; }

.content-placeholder{ background:transparent; }
.card{ background:#fff; border:1px solid #e6e8ef; border-radius:14px; box-shadow:0 10px 26px rgba(10,20,40,.06); padding:12px; }
.content-card{ display:flex; flex-direction:column; }
.ch{
  display:flex;
  align-items:flex-start;
  justify-content:space-between;
  gap:12px;
  padding:6px 6px 10px 6px;
}
.job-head-left{
  display:grid;
  gap:4px;
  min-width:0;
}
.job-head-right{
  display:flex;
  align-items:center;
  gap:6px;
  flex-wrap:wrap;
}
.ct{ font-weight:900; color:#111827; }
.sub{ font-size:12px; color:#6b7280; display:flex; align-items:center; gap:6px; }

.recipe-link-btn{
  border:none;
  background:transparent;
  padding:0;
  font-size:12px;
  color:#0b3aa4;
  font-weight:900;
  cursor:pointer;
}
.recipe-link-btn:hover{
  text-decoration:underline;
}

.job-classic{ background:#d4d0c8; border:1px solid #a7a7a7; border-radius:10px; padding:8px; display:grid; gap:8px; flex:1; overflow-y:auto; overflow-x:hidden; min-height:0; font-size:11px; }
.bar{ background:#d4d0c8; border:1px solid #8d8d8d; padding:4px 6px; display:flex; align-items:center; justify-content:space-between; gap:8px; }
.bar-left{ font-weight:900; color:#111; }
.bar-right{ display:flex; align-items:center; gap:8px; }
.bar-label{ font-size:11px; font-weight:900; }
.bar-select,.bar-input{ height:24px; padding:0 6px; border:1px solid #7f7f7f; background:#fff; }
.group{ border:1px solid #8d8d8d; background:#e6e2da; }
.group-head{ background:#d4d0c8; border-bottom:1px solid #8d8d8d; padding:4px 6px; font-weight:900; }
.tbl-wrap{ padding:6px; overflow-x:auto; }
.tight-tbl .tbl th, .tight-tbl .tbl td{ padding:3px 5px; }
.tbl{ border-collapse:collapse; width:max-content; min-width:100%; table-layout:fixed; font-size:11px; background:#fff; }
.tbl th,.tbl td{ border:1px solid #7f7f7f; padding:4px 6px; white-space:normal; word-break:break-word; }
.tbl th{ background:#d4d0c8; font-weight:900; position:relative; }
.rowname{ font-weight:900; background:#f3f3f3; }
.cell{ background:#fff; }
.tbl.polished th,.tbl.polished td{ text-align:center; }
.white{ background:#fff !important; }
.sky{ background:#39e6ff !important; font-weight:900; }
.platen1{ background:#fff; }
.platen2{ background:#39e6ff; font-weight:900; }
.platen3{ background:#fff; }
.click{ cursor:pointer; color:#0b3aa4; font-weight:900; }
.click:hover{ text-decoration:underline; background:#eaf7ff; }

.th-label{ display:block; }
.col-resizer{
  position:absolute;
  top:0;
  right:-4px;
  width:8px;
  height:100%;
  cursor:col-resize;
  z-index:2;
}
.col-resizer::after{
  content:'';
  position:absolute;
  top:0;
  left:3px;
  width:1px;
  height:100%;
  background:rgba(0,0,0,.18);
}

.bottom-recipe{ overflow-x:hidden; padding-bottom:140px; }
.legacy-window{ max-width:100%; overflow-x:hidden; background:#c0c0c0; border:1px solid #8d8d8d; padding:8px; border-radius:6px; }
.legacy-top{ display:grid; grid-template-columns:1fr 90px; gap:10px; align-items:start; margin-bottom:8px; }
.legacy-titlebar{ display:flex; align-items:center; gap:10px; background:#d4d0c8; border:1px solid #8d8d8d; padding:6px 8px; min-width:0; position:relative; }
.legacy-title{ font-weight:900; }
.legacy-meta{ font-weight:900; color:#111; }
.spacer{ flex:1; }
.okhide{ display:flex; flex-direction:column; gap:6px; }
.find-input{ width:240px; }
.recipe-scroll{ width:100%; display:flex; gap:12px; overflow-x:auto; overflow-y:hidden; padding:8px; background:#fff; border:1px solid #8d8d8d; height:170px; }
.recipe-col{ flex:0 0 200px; min-width:200px; border-right:1px solid #d0d0d0; padding-right:10px; }
.list-ul{ list-style:none; margin:0; padding:0; }
.list-li{ padding:2px 4px; cursor:pointer; line-height:18px; font-weight:800; }
.list-li.active{ background:#0a246a; color:#fff; }
.grid-wrap{ width:100%; background:#fff; border:1px solid #8d8d8d; overflow-x:hidden; overflow-y:auto; max-height:280px; }
.legacy-table{ width:100%; table-layout:fixed; border-collapse:collapse; font-size:10px; }
.legacy-table th,.legacy-table td{ border:1px solid #808080; padding:2px 4px; text-align:center; white-space:normal; word-break:break-word; overflow:hidden; text-overflow:ellipsis; }
.legacy-table th{ background:#d4d0c8; font-weight:900; }
.legacy-empty{ padding:10px; background:#fff; border:1px dashed #999; font-weight:900; color:#6b7280; }
.recipe-bottom-pad{ height:120px; }
.page-bottom-pad{ height:120px; }

.w97-menu{
  position: fixed;
  z-index: 9999;
  background: #c0c0c0;
  border-top:2px solid #fff; border-left:2px solid #fff;
  border-right:2px solid #404040; border-bottom:2px solid #404040;
  padding: 4px;
  min-width: 140px;
}
.w97-menu-item{
  padding: 4px 8px;
  font-weight: 900;
  cursor: pointer;
  background: #c0c0c0;
}
.w97-menu-item:hover{ background:#0a246a; color:#fff; }

.w97-modal-overlay{
  position: fixed; inset: 0;
  background: rgba(0,0,0,.35);
  display:flex; align-items:center; justify-content:center;
  z-index: 10000;
}
.w97-modal{
  width: 420px;
  background:#c0c0c0;
  border-top:2px solid #fff; border-left:2px solid #fff;
  border-right:2px solid #404040; border-bottom:2px solid #404040;
}
.w97-modal-titlebar{ background:#0a246a; color:#fff; padding:6px 8px; font-weight:900; }
.w97-modal-body{ padding:12px; font-weight:900; }
.w97-modal-actions{ padding:0 12px 12px 12px; display:flex; gap:8px; justify-content:flex-end; }

.picker{ width:min(1100px, 92vw); }
.picker-titlebar{ margin-bottom:8px; }
.picker-grid{
  display:grid;
  grid-template-rows:220px minmax(260px, 1fr);
  gap:10px;
}
.picker-scroll{ height:220px; }
.picker-preview{
  background:#fff;
  border-top:2px solid #808080;
  border-left:2px solid #808080;
  border-right:2px solid #fff;
  border-bottom:2px solid #fff;
  padding:8px;
  overflow:auto;
  min-height:260px;
  max-height:420px;
}
.picker-preview-title{ font-weight:900; margin-bottom:8px; }
.picker-preview-tablewrap{ overflow:auto; }

.attention-job-list{
  box-shadow:0 0 0 3px rgba(16,185,129,.75), 0 0 22px rgba(16,185,129,.25);
  animation:iphoneShake .62s cubic-bezier(.36,.07,.19,.97) both;
}
@keyframes iphoneShake{
  0%{ transform:translate3d(0,0,0); }
  10%{ transform:translate3d(-7px,0,0) rotate(-1deg); }
  20%{ transform:translate3d(7px,0,0) rotate(1deg); }
  30%{ transform:translate3d(-6px,0,0) rotate(-1deg); }
  40%{ transform:translate3d(6px,0,0) rotate(1deg); }
  50%{ transform:translate3d(-4px,0,0) rotate(-.6deg); }
  60%{ transform:translate3d(4px,0,0) rotate(.6deg); }
  70%{ transform:translate3d(-2px,0,0); }
  80%{ transform:translate3d(2px,0,0); }
  100%{ transform:translate3d(0,0,0); }
}

.slideCard-enter-active,.slideCard-leave-active{ transition:opacity .22s ease, transform .22s ease; }
.slideCard-enter-from,.slideCard-leave-to{ opacity:0; transform:translateY(-6px); }
.slideCard-enter-to,.slideCard-leave-from{ opacity:1; transform:translateY(0); }
.slideDown-enter-active,.slideDown-leave-active{ transition:max-height .26s ease, opacity .22s ease; overflow:hidden; }
.slideDown-enter-from,.slideDown-leave-to{ max-height:0; opacity:0; }
.slideDown-enter-to,.slideDown-leave-from{ max-height:5000px; opacity:1; }
</style>
