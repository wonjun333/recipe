export type GridCell = string | number | null
export type GridRow = Record<string, GridCell>

export type RecipeDetail = {
  id: string
  name: string
  columns: string[]
  rows: GridRow[]
}

export type FileEntry = {
  name: string
  modifiedAt: string
  size?: string
  rawLine?: string
}

export type JobConfigPayload = {
  p1: string
  p2: string
  p3: string
  piPre: 'NONE' | 'DATA'
  piPost: 'NONE' | 'DATA'
  unloadModule: 'NONE' | 'DATA'
}

export type LoadRequest = {
  line: string
  team: string
  eqpId: string
}

export type EqpOptionItem = {
  line: string
  team: string
  eqpId: string
  model?: string
}

export type EqpOptionsResponse = {
  items: EqpOptionItem[]
  lineOptions: string[]
  teamOptions: string[]
  eqpOptions: string[]
}

export type LoadResponse = {
  eqpId: string
  meta?: {
    ftpServer?: string
    resolvedPaths?: {
      base?: string | null
      cas?: string | null
      job?: string | null
      recipe?: string | null
    }
    childrenUnderLcmp?: string[]
    counts?: {
      cas: number
      job: number
      recipe: number
    }
  }
  casList: FileEntry[]
  jobList: Array<{
    id: string
    jobName: string
    recipeName: string
    modifiedAt: string
  }>
  recipeList: Array<{
    id: string
    name: string
    modifiedAt?: string
  }>
  casToJobs?: Record<string, string[]>
}

export type CasContentResponse = {
  casId: string
  slots: Array<{
    slot: number
    jobId: string
    jobName: string
    recipeName: string
  }>
  jobIds?: string[]
  raw?: string
}

export type JobContentResponse = {
  jobId: string
  jobName: string
  baseRecipeName: string
  config: JobConfigPayload
}

export type RecipeContentResponse = {
  recipe: RecipeDetail
}

const API_BASE = ''

async function http<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: {
      'Content-Type': 'application/json',
    },
    ...init,
  })

  if (!res.ok) {
    const text = await res.text()
    throw new Error(text || 'API request failed')
  }

  return res.json() as Promise<T>
}

export const recipeTestApi = {
  getEqpOptions() {
    return http<EqpOptionsResponse>('/api/recipe-test/eqp-options')
  },

  load(body: LoadRequest) {
    return http<LoadResponse>('/api/recipe-test/load', {
      method: 'POST',
      body: JSON.stringify(body),
    })
  },

  getCasContent(eqpId: string, casId: string) {
    const qs = new URLSearchParams({ eqpId, casId }).toString()
    return http<CasContentResponse>(`/api/recipe-test/cas-content?${qs}`)
  },

  getJobContent(eqpId: string, jobId: string) {
    const qs = new URLSearchParams({ eqpId, jobId }).toString()
    return http<JobContentResponse>(`/api/recipe-test/job-content?${qs}`)
  },

  getRecipeContent(eqpId: string, recipeId: string) {
    const qs = new URLSearchParams({ eqpId, recipeId }).toString()
    return http<RecipeContentResponse>(`/api/recipe-test/recipe-content?${qs}`)
  },

  saveCas(
    eqpId: string,
    casId: string,
    slots: Array<{
      slot: number
      jobId: string
      jobName: string
      recipeName: string
    }>
  ) {
    return http<{ status: string }>('/api/recipe-test/cas/save', {
      method: 'POST',
      body: JSON.stringify({ eqpId, casId, slots }),
    })
  },

  saveJob(eqpId: string, jobId: string, config: JobConfigPayload) {
    return http<{ status: string }>('/api/recipe-test/job/save', {
      method: 'POST',
      body: JSON.stringify({ eqpId, jobId, config }),
    })
  },
}
