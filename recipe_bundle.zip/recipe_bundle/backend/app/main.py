from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes.recipe_test import router as recipe_test_router

app = FastAPI(title="recipe-backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:5174",
        "http://127.0.0.1:5174",
        "http://localhost:5175",
        "http://127.0.0.1:5175",
        "http://localhost:5176",
        "http://127.0.0.1:5176",
        "http://localhost:5177",
        "http://127.0.0.1:5177",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(recipe_test_router, prefix="/api")


@app.get("/health")
def health():
    return {"status": "ok"}
