from __future__ import annotations

import ftplib
import re
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from pymongo import MongoClient

router = APIRouter(prefix="/recipe-test", tags=["recipe-test"])

NONE_LABEL = "(None)"

BOOTSTRAP_CACHE: dict[str, dict[str, Any]] = {}
CAS_CACHE: dict[tuple[str, str], dict[str, Any]] = {}
JOB_CACHE: dict[tuple[str, str], dict[str, Any]] = {}
RECIPE_CACHE: dict[tuple[str, str], dict[str, Any]] = {}

DIR_LINE_RE = re.compile(
    r"^\s*(\d{2}-\d{2}-\d{2})\s+(\d{2}:\d{2}[AP]M)\s+(\d+)\s+(.+?)\s*$"
)


class LoadRequest(BaseModel):
    line: str
    team: str
    eqpId: str


class SaveCasRequest(BaseModel):
    eqpId: str
    casId: str
    slots: list[dict[str, Any]]


class SaveJobRequest(BaseModel):
    eqpId: str
    jobId: str
    config: dict[str, Any]


def load_eqp_ip(eqp_id: str) -> tuple[str, str, str]:
    client = MongoClient(
        "mongodb://10.11.12.18:277/",
        serverSelectionTimeoutMS=3000,
    )
    try:
        db = client["ADD"]
        collection = db["FTP_STATUS"]

        doc = collection.find_one(
            {"EQPID": eqp_id},
            {
                "_id": 0,
                "FTP_SERVER": 1,
                "FTP_ID": 1,
                "FTP_PW": 1,
            },
        )

        if not doc:
            raise ValueError(f"EQPID not found: {eqp_id}")

        ftp_ip = doc.get("FTP_SERVER")
        ftp_id = doc.get("FTP_ID")
        ftp_pw = doc.get("FTP_PW")

        if not isinstance(ftp_ip, str) or not ftp_ip.strip():
            raise ValueError("FTP_SERVER is missing")
        if not isinstance(ftp_id, str) or not ftp_id.strip():
            raise ValueError("FTP_ID is missing")
        if not isinstance(ftp_pw, str):
            raise ValueError("FTP_PW is missing")

        return ftp_ip, ftp_id, ftp_pw
    finally:
        client.close()


def load_eqp_master_options() -> list[dict[str, str]]:
    """
    EQP_MASTER 실필드:
    - line
    - PART_NAME
    - EQPID
    - MODEL
    """
    client = MongoClient(
        "mongodb://10.12.13.18:27/",
        serverSelectionTimeoutMS=3000,
    )
    try:
        db = client["ADD"]
        collection = db["EQP_MASTER"]

        docs = list(collection.find(
            {},
            {
                "_id": 0,
                "line": 1,
                "PART_NAME": 1,
                "EQPID": 1,
                "MODEL": 1,
            }
        ))

        results: list[dict[str, str]] = []
        for doc in docs:
            line = str(doc.get("line", "")).strip()
            team = str(doc.get("PART_NAME", "")).strip()
            eqp_id = str(doc.get("EQPID", "")).strip()
            model = str(doc.get("MODEL", "")).strip()

            if not line or not team or not eqp_id:
                continue

            results.append({
                "line": line,
                "team": team,
                "eqpId": eqp_id,
                "model": model,
            })

        unique = {(x["line"], x["team"], x["eqpId"]): x for x in results}
        return sorted(unique.values(), key=lambda x: (x["line"], x["team"], x["eqpId"]))
    finally:
        client.close()


def ftp_dir_entries(ftp: ftplib.FTP) -> list[dict[str, str]]:
    """
    FTP dir 원문 예시:
    06-25-18  09:50AM               151616 [DD]OBI2_47.cas
    반환:
    {
        "name": "[DD]OBI2_47.cas",
        "modifiedAt": "06-25-18 09:50AM",
        "size": "151616",
        "rawLine": "..."
    }
    """
    lines: list[str] = []
    ftp.dir(lines.append)

    items: list[dict[str, str]] = []
    for line in lines:
        line = line.rstrip()
        m = DIR_LINE_RE.match(line)

        if m:
            date_part = m.group(1)
            time_part = m.group(2)
            size_part = m.group(3)
            name_part = m.group(4).strip()

            if name_part in ("", ".", ".."):
                continue

            items.append({
                "name": name_part,
                "modifiedAt": f"{date_part} {time_part}",
                "size": size_part,
                "rawLine": line,
            })
            continue

        parts = line.split()
        if not parts:
            continue

        name_part = parts[-1].strip()
        if name_part in ("", ".", ".."):
            continue

        items.append({
            "name": name_part,
            "modifiedAt": "",
            "size": "",
            "rawLine": line,
        })

    return items


def pick_child_name(children: list[str], keywords: list[str]) -> str | None:
    for name in children:
        low = name.lower()
        if any(k in low for k in keywords):
            return name
    return None


def list_entries_in_child(ftp: ftplib.FTP, base_path: str, child_name: str) -> list[dict[str, str]]:
    ftp.cwd(base_path)
    ftp.cwd(child_name)
    return ftp_dir_entries(ftp)


def get_ftp_file_list(ftp_ip: str, ftp_id: str, ftp_pw: str):
    """
    주의:
    이 함수는 반드시 list[str] 가 아니라 list[dict] 를 반환해야 함.
    그렇지 않으면 load_recipe_test 에서 x["name"] 접근 시
    'string indices must be integers' 에러가 발생함.
    """
    try:
        ftp = ftplib.FTP(timeout=10)
        ftp.connect(ftp_ip, 21)
        ftp.login(user=ftp_id, passwd=ftp_pw)

        base_path = r"\CMPDB\Lcmp"
        ftp.cwd(base_path)
        print(f"[FTP] base ok -> {ftp.pwd()}")

        children_entries = ftp_dir_entries(ftp)
        children = [x["name"] for x in children_entries]
        print(f"[FTP] children under {base_path}: {children}")

        cas_dir = pick_child_name(children, ["cas"])
        job_dir = pick_child_name(children, ["job"])
        recipe_dir = pick_child_name(children, ["recipe", "rcp", "rec"])

        if not cas_dir:
            raise RuntimeError(f"CAS directory not found under {base_path}. children={children}")
        if not job_dir:
            raise RuntimeError(f"JOB directory not found under {base_path}. children={children}")

        cas_list = list_entries_in_child(ftp, base_path, cas_dir)
        job_list = list_entries_in_child(ftp, base_path, job_dir)

        if recipe_dir:
            try:
                recipe_list = list_entries_in_child(ftp, base_path, recipe_dir)
            except Exception as e:
                print(f"[FTP] recipe list failed, continue empty: {e}")
                recipe_list = []
        else:
            print(f"[FTP] recipe dir not found under {base_path}, continue empty")
            recipe_list = []

        ftp.quit()

        print(f"[FTP] resolved dirs => cas={cas_dir}, job={job_dir}, recipe={recipe_dir}")
        print(f"[FTP] counts => cas={len(cas_list)}, job={len(job_list)}, recipe={len(recipe_list)}")

        return {
            "cas_list": cas_list,
            "job_list": job_list,
            "recipe_list": recipe_list,
            "resolved_paths": {
                "base": base_path,
                "cas": cas_dir,
                "job": job_dir,
                "recipe": recipe_dir,
            },
            "children": children,
        }

    except Exception as e:
        raise RuntimeError(f"FTP list load failed: {e}") from e


def make_job_id(job_name: str) -> str:
    return f"JOB::{job_name}"


def make_recipe_id(recipe_name: str) -> str:
    return f"RCP::{recipe_name}"


@router.get("/eqp-options")
def get_eqp_options():
    try:
        items = load_eqp_master_options()
        return {
            "items": items,
            "lineOptions": sorted(set(x["line"] for x in items)),
            "teamOptions": sorted(set(x["team"] for x in items)),
            "eqpOptions": sorted(set(x["eqpId"] for x in items)),
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/load")
def load_recipe_test(req: LoadRequest):
    try:
        ftp_ip, ftp_id, ftp_pw = load_eqp_ip(req.eqpId)

        ftp_result = get_ftp_file_list(ftp_ip, ftp_id, ftp_pw)
        cas_entries = ftp_result["cas_list"]
        job_entries = ftp_result["job_list"]
        recipe_entries = ftp_result["recipe_list"]

        # 여기서 cas_entries/job_entries/recipe_entries 는 list[dict] 여야 함
        recipe_list = [
            {"id": make_recipe_id(x["name"]), "name": x["name"], "modifiedAt": x["modifiedAt"]}
            for x in recipe_entries
        ]

        first_recipe_name = recipe_entries[0]["name"] if recipe_entries else NONE_LABEL

        job_list = [
            {
                "id": make_job_id(x["name"]),
                "jobName": x["name"],
                "recipeName": first_recipe_name,
                "modifiedAt": x["modifiedAt"],
            }
            for x in job_entries
        ]

        data = {
            "eqpId": req.eqpId,
            "meta": {
                "ftpServer": ftp_ip,
                "resolvedPaths": ftp_result["resolved_paths"],
                "childrenUnderLcmp": ftp_result["children"],
                "counts": {
                    "cas": len(cas_entries),
                    "job": len(job_entries),
                    "recipe": len(recipe_entries),
                },
            },
            "casList": cas_entries,
            "jobList": job_list,
            "recipeList": recipe_list,
            "casToJobs": {},
        }

        BOOTSTRAP_CACHE[req.eqpId] = data
        return data

    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/cas-content")
def get_cas_content(eqpId: str, casId: str):
    cache_key = (eqpId, casId)
    if cache_key in CAS_CACHE:
        return CAS_CACHE[cache_key]

    bootstrap = BOOTSTRAP_CACHE.get(eqpId)
    if not bootstrap:
        raise HTTPException(status_code=400, detail="Load 먼저 실행하세요.")

    job_list = bootstrap.get("jobList", [])
    if not job_list:
        slots = [
            {"slot": i, "jobId": "J_NONE", "jobName": NONE_LABEL, "recipeName": ""}
            for i in range(1, 25)
        ]
    else:
        slots = []
        for i in range(1, 25):
            picked = job_list[(i - 1) % len(job_list)]
            slots.append(
                {
                    "slot": i,
                    "jobId": picked["id"],
                    "jobName": picked["jobName"],
                    "recipeName": picked["recipeName"],
                }
            )

    result = {
        "casId": casId,
        "slots": slots,
        "jobIds": list({x["jobId"] for x in slots if x["jobId"] != "J_NONE"}),
    }
    CAS_CACHE[cache_key] = result
    return result


@router.get("/job-content")
def get_job_content(eqpId: str, jobId: str):
    cache_key = (eqpId, jobId)
    if cache_key in JOB_CACHE:
        return JOB_CACHE[cache_key]

    bootstrap = BOOTSTRAP_CACHE.get(eqpId)
    if not bootstrap:
        raise HTTPException(status_code=400, detail="Load 먼저 실행하세요.")

    job = next((x for x in bootstrap["jobList"] if x["id"] == jobId), None)
    if not job:
        raise HTTPException(status_code=404, detail=f"job not found: {jobId}")

    recipe_name = job["recipeName"]

    result = {
        "jobId": jobId,
        "jobName": job["jobName"],
        "baseRecipeName": recipe_name,
        "config": {
            "p1": recipe_name,
            "p2": recipe_name,
            "p3": recipe_name,
            "piPre": "NONE",
            "piPost": "DATA",
            "unloadModule": "DATA",
        },
    }
    JOB_CACHE[cache_key] = result
    return result


@router.get("/recipe-content")
def get_recipe_content(eqpId: str, recipeId: str):
    cache_key = (eqpId, recipeId)
    if cache_key in RECIPE_CACHE:
        return RECIPE_CACHE[cache_key]

    bootstrap = BOOTSTRAP_CACHE.get(eqpId)
    if not bootstrap:
        raise HTTPException(status_code=400, detail="Load 먼저 실행하세요.")

    recipe = next((x for x in bootstrap["recipeList"] if x["id"] == recipeId), None)
    if not recipe:
        raise HTTPException(status_code=404, detail=f"recipe not found: {recipeId}")

    result = {
        "recipe": {
            "id": recipe["id"],
            "name": recipe["name"],
            "columns": ["Key", "Value"],
            "rows": [
                {"Key": "RECIPE_NAME", "Value": recipe["name"]},
                {"Key": "STATUS", "Value": "PLACEHOLDER_PREVIEW"},
                {"Key": "NOTE", "Value": "여기에 실제 decode 결과를 연결할 예정"},
            ],
        }
    }
    RECIPE_CACHE[cache_key] = result
    return result


@router.post("/cas/save")
def save_cas(req: SaveCasRequest):
    cache_key = (req.eqpId, req.casId)
    CAS_CACHE[cache_key] = {
        "casId": req.casId,
        "slots": req.slots,
        "jobIds": list({x["jobId"] for x in req.slots if x.get("jobId") and x["jobId"] != "J_NONE"}),
    }
    return {"status": "saved_to_cache"}


@router.post("/job/save")
def save_job(req: SaveJobRequest):
    cache_key = (req.eqpId, req.jobId)
    bootstrap = BOOTSTRAP_CACHE.get(req.eqpId)
    job_name = req.jobId
    base_recipe_name = req.config.get("p1", NONE_LABEL)

    if bootstrap:
        found = next((x for x in bootstrap["jobList"] if x["id"] == req.jobId), None)
        if found:
            job_name = found["jobName"]
            base_recipe_name = found.get("recipeName", base_recipe_name)

    JOB_CACHE[cache_key] = {
        "jobId": req.jobId,
        "jobName": job_name,
        "baseRecipeName": base_recipe_name,
        "config": req.config,
    }
    return {"status": "saved_to_cache"}
